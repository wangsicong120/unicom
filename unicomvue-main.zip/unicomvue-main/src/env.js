export const APP_BRANCH =
  typeof __APP_BRANCH__ !== "undefined" ? __APP_BRANCH__ : "";

export const APP_COMMIT =
  typeof __APP_COMMIT__ !== "undefined" ? __APP_COMMIT__ : "";

export const APP_BUILD_TIME =
  typeof __APP_BUILD_TIME__ !== "undefined" ? __APP_BUILD_TIME__ : "";
